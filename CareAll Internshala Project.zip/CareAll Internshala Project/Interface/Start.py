from abc import ABC, abstractmethod

class Start_Interface(ABC):

    @abstractmethod
    def sign_up(self,):
        pass

    @abstractmethod
    def login_young(self,):
        pass

    @abstractmethod
    def login_elder(self,):
        pass
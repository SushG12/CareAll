from abc import ABC, abstractmethod

class Elder_Interface(ABC):

    @abstractmethod
    def insert_details(self):
        pass
    @abstractmethod
    def elder_response(self):
        pass
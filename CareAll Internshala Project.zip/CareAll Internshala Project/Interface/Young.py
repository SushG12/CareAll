from abc import ABC, abstractmethod

class Young_Interface(ABC):

    @abstractmethod
    def insert_details(self):
        pass
    @abstractmethod
    def young_request(self):
        pass
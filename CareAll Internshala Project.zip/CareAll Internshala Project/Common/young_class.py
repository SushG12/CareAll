from Interface.Young import Young_Interface
from Common.database_class import Database

db = Database()

class Young(Young_Interface):
    
    def __init__(self, name='', addr='', city='', phone=00,username = '',password = ''):
        self.__name = name
        self.__addr = addr
        self.__city = city
        self.__phone = phone
        self.__username = username
        self.__password = password
        self.elder_id = 0
        
    @property   #name
    def name(self):
        return self.__name  

    @name.setter  
    def name(self, myname):
        self.__name = myname

    @property   #addr
    def addr(self):
        return self.__addr

    @addr.setter  
    def addr(self, myaddr):
        self.__addr = myaddr

    @property   #city
    def city(self):
        return self.__city

    @city.setter  
    def city(self, mycity):
        self.__city = mycity

    @property   #phone
    def phone(self):
        return self.__phone
        
    @phone.setter  
    def phone(self, myphone):
        self.__phone = myphone

    @property   #username
    def username(self):
        return self.__username
        
    @username.setter  
    def username(self, uname):
        self.__username = uname

    @property   #password
    def password(self):
        return self.__password
        
    @password.setter  
    def password(self, mypassword):
        self.__password = mypassword
    
    def insert_details(self,):
        db.insert_young(self.name, self.addr, self.city, self.phone, self.username, self.password)
     
    def display_details(self,):
        db.display_table('YOUNG')

    def young_request(self,):
        print('\nPlease select an oldy from below lists (you can select multiple requests): \n')
        db.display_table('ELDER')
        length = 1
        while length <= len(db.count_record):
            if self.elder_id == 999:
                print('Exit from while loop')
                break
            else:
                self.elder_id = int(input(f'Enter the {length}st id of person: (enter 999 for exit)'))
                db.insert_young_request_table(self.elder_id)
            length += 1

        


    
            




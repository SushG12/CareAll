from Interface.Start import Start_Interface
from Common.database_class import Database
from Common.elder_class import Elder
from Common.young_class import Young

db = Database()
young = Young()
elder = Elder()

db.create_table()

class Start_Application(Start_Interface):

    def sign_up(self,option):

        print('Welcome, Please fill out the form first :')

        if option == 1:
            young.name = input('Name: ')
            young.addr = input('Address: ')
            young.city = input('City: ')
            young.phone = int(input('Phone: '))
            print('\nSigned Up Successfully !\n')
            print('\nSetup the credential: \n')
            young.username = input('\nUsername: ')
            young.password = input('\nPassowrd: ')
            young.insert_details()
            #young.display_details()
        
        else:
            elder.name = input('Name: ')
            elder.age = int(input('Age: '))
            elder.gender = input('Gender(M/F): ')
            while True:
                c = input('Are you joining as a couple(y/n): ')
                if c == 'y':
                    elder.couple = 1
                    break
                elif c == 'n':
                    elder.couple = 0
                    break
                else:
                    print('Enter a valid input')
            elder.addr = input('Address: ')
            elder.phone = int(input('Phone: '))
            elder.funds = int(input('Funding Amount: '))  
            print('\nSigned Up Successfully !\n')
            print('\nSetup the credential: \n')
            elder.username = input('\nUsername: ')
            elder.password = input('\nPassowrd: ')
            elder.insert_details()
            #elder.display_details()

    def login_young(self):
        user = input('\nEnter username:\n')
        password = input('\nEnter password:\n')

        if db.check_young_credential(user, password) == True:
            choose = input('\nChoose below options:\n\n1. Send Request\n2. Review and Ratings\n3. Exit\n\n')
            if choose == 1:
                young.young_request()
            elif choose == 2:
                db.insert_young_reviews_ratings()
            else:
                print('\n***Thank you for visiting***\n')

        else:
            print('\nHey! New User\n')
            self.sign_up(1)
            choose = input('\nChoose below options:\n\n1. Send Request\n2. Review and Ratings\n3. Exit\n\n')
            if choose == 1:
                young.young_request()
            elif choose == 2:
                db.insert_young_reviews_ratings()
            else:
                print('\n***Thank you for visiting***\n')

    def login_elder(self):
        user = input('Enter username:\n\n')
        password = input('Enter password:\n\n')

        if db.check_elder_credential(user, password) == True:
            choose = input('\nChoose below options:\n\n1. Check Response\n2. Review and Ratings\n3. Exit\n\n')
            if choose == 1:
                elder.elder_response()
            elif choose == 2:
                db.insert_elder_reviews_ratings()
            else:
                print('\n***Thank you for visiting***\n')
            
        else:
            print('\nHey! New User\n')
            self.sign_up(2)
            choose = input('\nChoose below options:\n\n1. Check Response\n2. Review and Ratings\n3. Exit\n\n')
            if choose == 1:
                elder.elder_response()
            elif choose == 2:
                db.insert_elder_reviews_ratings()
            else:
                print('\n***Thank you for visiting***\n')

    def start(self):
        who = int(input('Young or Elder (1/2): '))
        if who == 1:
            self.login_young()
        else:
            self.login_elder()










    





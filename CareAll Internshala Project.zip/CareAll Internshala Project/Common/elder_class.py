from Interface.Elder import Elder_Interface
from Common.database_class import Database

db = Database()

class Elder(Elder_Interface):
  
    def __init__(self, name='', age=0, sex='', couple='', addr='', phone=00, funds = 0,username='',password=''):
        self.__name = name
        self.__age = age
        self.__sex = sex
        self.__couple = couple
        self.__addr = addr
        self.__phone = phone
        self.__funds = funds
        self.__username = username
        self.__password = password
      
    
    @property   #name
    def name(self):
        return self.__name  

    @name.setter  
    def name(self, myname):
        self.__name = myname
    
    @property   #age
    def age(self):
        return self.__age  

    @age.setter  
    def age(self, myage):
        self.__age = myage
    
    @property   #sex
    def sex(self):
        return self.__sex

    @sex.setter  
    def sex(self, gender):
        self.__sex = gender
    
    @property   #couple
    def couple(self):
        return self.__couple   

    @couple.setter  
    def couple(self, couples):
        self.__couple = couples
    
    @property   #addr
    def addr(self):
        return self.__addr

    @addr.setter  
    def addr(self, myaddr):
        self.__addr = myaddr
    
    @property   #phone
    def phone(self):
        return self.__phone
        
    @phone.setter  
    def phone(self, myphone):
        self.__phone = myphone

    @property   #funds
    def funds(self):
        return self.__funds
        
    @funds.setter  
    def funds(self, amount):
        self.__funds = amount
        
    @property   #username
    def username(self):
        return self.__username
        
    @username.setter  
    def username(self, uname):
        self.__username = uname

    @property   #password
    def password(self):
        return self.__password
        
    @password.setter  
    def password(self, mypassword):
        self.__password = mypassword

    def insert_details(self):
        db.insert_elder(self.name, self.age, self.sex, self.couple, self.addr, self.phone, self.__funds,self.username, self.password)
    
    def display_details(self):
        db.display_table('ELDER')
        db.display_table('FUNDS')
        
    def delete_details(self):
        db.delete_table('ELDER')
        db.delete_table('FUNDS')
        db.delete_table('ELDER_CREDENTIAL')

    def elder_response(self):
        print('\nChoose a taker for a month from below list: \n')
        db.elder_response_table()
        print('\nEnter the id of the caretaker: ')
        while True:
            id = int(input())
            print(f'ID you seleceted is: {id}')
            response = db.update_elder_response_table(id)
            if response == False:
                print('Please enter the ID once again: ')
                continue
            else:
                break


        

        
# -*- coding: utf-8 -*-
"""
Created on Sat Jan  4 11:05:33 2020

@author: Admin
"""
#!/usr/bin/python
import sqlite3
import pandas as pd

class Database:
    
    def __init__(self):
        self.count_record = 0
        self.yid = 0
        self.eid = 0
    
    def create_table(self):
        
        conn = sqlite3.connect('careall.db')
        
        conn.execute('''CREATE TABLE IF NOT EXISTS YOUNG
                (YID        INTEGER PRIMARY KEY, 
                 YNAME      TEXT NOT NULL,
                 YADDRESS   TEXT, 
                 CITY       TEXT,
                 PHONE      INT)''')
        print('Young table created suceesfully')

        conn.execute('''CREATE TABLE IF NOT EXISTS ELDER
                (EID        INTEGER PRIMARY KEY,
                 ENAME      TEXT NOT NULL, 
                 AGE        TEXT, 
                 SEX        TEXT,
                 COUPLES    BOOL, 
                 EADDRESS   TEXT, 
                 PHONE      INT)''')
        print('Elder table created suceesfully')
        
        conn.execute('''CREATE TABLE IF NOT EXISTS FUNDS
                (FID        INTEGER PRIMARY KEY, 
                 F_EID      INT, 
                 FUND       INT, 
                 FOREIGN KEY (F_EID) REFERENCES ELDER(EID))''')
        
        print('funds table created suceesfully')
        
        conn.execute('''CREATE TABLE IF NOT EXISTS YOUNG_CREDENTIAL
                  (YID       INT,
                  USERNAME   TEXT,
                   PASSWORD  TEXT,
                   FOREIGN KEY(YID) REFERENCES YOUNG(YID))''')
        print('young_credential table created suceesfully')

        conn.execute('''CREATE TABLE IF NOT EXISTS ELDER_CREDENTIAL
                  (EID       INT,
                  USERNAME   TEXT,
                   PASSWORD  TEXT,
                   FOREIGN KEY (EID) REFERENCES ELDER(EID))''')
        print('young_credential table created suceesfully')

        
        conn.execute('''CREATE TABLE IF NOT EXISTS YOUNG_REQUEST_PAGE
                  (REQUEST_ID   INTEGER PRIMARY KEY, 
                   MYYID        INT,
                   EID          INT, 
                   STATUS       TEXT,
                   FOREIGN KEY (MYYID) REFERENCES YOUNG(YID),
                   FOREIGN KEY (EID) REFERENCES ELDER(EID))''')
        
        conn.execute('''CREATE TABLE IF NOT EXISTS ELDER_RESPONSE_PAGE
                  (REQUEST_ID   INTEGER PRIMARY KEY, 
                   MYEID        INT,
                   YID          INT, 
                   STATUS       TEXT,
                   FOREIGN KEY (MYEID) REFERENCES ELDER(EID),
                   FOREIGN KEY (YID) REFERENCES YOUNG(YID))''')

        conn.execute('''CREATE TABLE IF NOT EXISTS YOUNG_REVIEWS_RATINGS
                  (YID      INT, 
                   EID      INT, 
                   REVIEWS  TEXT,
                   RATINGS  INT,
                   FOREIGN KEY (YID) REFERENCES YOUNG(YID),
                   FOREIGN KEY (EID) REFERENCES ELDER(EID))''')
        print('yrr table created suceesfully')
        
        conn.execute('''CREATE TABLE IF NOT EXISTS ELDER_REVIEWS_RATINGS
                  (EID      INT, 
                   YID      INT, 
                   REVIEWS  TEXT,
                   RATINGS  INT,
                   FOREIGN KEY (EID) REFERENCES ELDER(EID),
                   FOREIGN KEY (YID) REFERENCES YOUNG(YID))''')
        print('err table created suceesfully')
        
        conn.commit()
        print('Commited SUccesfully')
        conn.close()
        print('Database closed succesfully')

    def insert_young(self, *args):
        conn = sqlite3.connect('careall.db')
        conn.execute('INSERT INTO YOUNG \
                     (YNAME, YADDRESS, CITY, PHONE) \
                     VALUES (?,?,?,?)',
                     (args[0],args[1],args[2],args[3]))
        
        print('inserted into young table successfully')

        conn.execute(f'INSERT INTO YOUNG_CREDENTIAL \
                     (YID, USERNAME, PASSWORD) \
                     VALUES (?,?,?)',
                     (args[0],args[4],args[5]))
        
        print('inserted into young credential table successfully')  

        conn.execute('COMMIT')
        conn.close()
        
    def insert_elder(self, *args):
        conn = sqlite3.connect('careall.db')
        conn.execute('INSERT INTO ELDER \
                     (ENAME, AGE, SEX, COUPLES, EADDRESS, PHONE) \
                     VALUES (?,?,?,?,?,?)',
                     (args[0],args[1],args[2],args[3],args[4], args[5]))
        
        print('inserted into elder table Successfully')
        
        c = conn.execute('SELECT * FROM ELDER')
        conn.execute('INSERT INTO FUNDS \
                     (F_EID, FUND) \
                     VALUES (?,?)',
                     (c.lastrowid, args[6]))
        
        print('inserted into funds table successfully')
        
        conn.execute(f'INSERT INTO ELDER_CREDENTIAL \
                     (EID, USERNAME, PASSWORD) \
                     VALUES (?,?,?)',
                     (args[0],args[7],args[8]))
        
        print('inserted into elder credential table successfully')
        conn.execute('COMMIT')
        conn.close()
        
    def display_table(self, table):
        conn = sqlite3.connect('careall.db')
        conn.row_factory = sqlite3.Row
        print(f'Displaying {table} table: \n\n')
        y = conn.execute(f'SELECT * FROM {table}')
        data=[]
        mydata = []
        for row in y:
            data.append(dict(row))
        col = list(data[0].keys())
        for i in range(len(data)):
            mydata.append(list(data[i].values()))
        self.count_record = len(mydata)
        df = pd.DataFrame(mydata, columns=col)
        print(df)
        print('\n')
        conn.commit()
        conn.close()

    def delete_table(self, table):
        conn = sqlite3.connect('careall.db')
        print(f'Deleting {table} table: ')
        y = conn.execute(f'DROP TABLE {table}')
        for row in y:
            print(row)
        conn.commit()
        conn.close()

    def check_young_credential(self,user, pwd):
        conn = sqlite3.connect('careall.db')
        conn.row_factory = sqlite3.Row
        print(f'Merging the tables : \n\n')
        y = conn.execute(f'SELECT * FROM  YOUNG_CREDENTIAL')
        data=[]
        for row in y:
            data.append(dict(row))
        for record in data:
            if record['username'] == user and record['password'] == pwd:
                self.yid = myid =  record['eid']
                c=conn.execute(f'SELECT * FROM  YOUNG_CREDENTIAL c inner join YOUNG t on c.EID = t.EID')
                merge_data = []
                for row in c:
                    merge_data.append(dict(c))
                df = pd.DataFrame(data)
                name = df[df['EID'] == myid]['ENAME']
                print(f'Welcome {name}')
                conn.close()
                return True
            else:
                return False

    def check_elder_credential(self,user, pwd):
        conn = sqlite3.connect('careall.db')
        conn.row_factory = sqlite3.Row
        print(f'Merging the tables : \n\n')
        y = conn.execute(f'SELECT * FROM  ELDER_CREDENTIAL')
        data=[]
        for row in y:
            data.append(dict(row))
        for record in data:
            if record['username'] == user and record['password'] == pwd:
                self.eid = myid =  record['eid']
                c=conn.execute(f'SELECT * FROM  ELDER_CREDENTIAL c inner join ELDER t on c.EID = t.EID')
                merge_data = []
                for row in c:
                    merge_data.append(dict(c))
                df = pd.DataFrame(data)
                name = df[df['EID'] == myid]['ENAME']
                print(f'Welcome {name}')
                return True
            else:
                return False

    def insert_young_request_table(self, elder_id):

        conn = sqlite3.connect('careall.db')
        c = conn.execute('SELECT COUNT(STATUS) FROM YOUNG_REQUEST_PAGE \
                           WHERE STATUS="accepted" ')
        if c.fetchone()[0] >= 4:
            print('OOPS! Cannot send more request...')
    
        else:
            conn.execute(f'INSERT INTO YOUNG_REQUEST_PAGE \
                        (MYYID, EID, STATUS) \
                        VALUES (?,?,?)',

                        (self.yid, elder_id,'requested'))
            
            print('inserted into young request table successfully\n')

            conn.execute(f'INSERT INTO ELDER_RESPONSE_TABLE \
                        (MYEID, YID, STATUS) \
                        VALUES (?,?,?)',

                        (elder_id, self.yid,'pending...'))

            print('inserted into elder request table successfully\n')            
                     
        conn.commit()
        conn.close()

    def elder_response_table(self):
        conn = sqlite3.connect('careall.db')
        conn.row_factory = sqlite3.Row
        c = conn.execute(f'SELECT *.ER  FROM ELDER_RESPONSE_TABLE ER INNER JOIN YOUNG Y ON ER.YID = Y.YID \
                            WHERE ER.MYEID={self.eid}')
        data = []
        for row in c:
            data.append(dict(row))

        df = pd.DataFrame(data)
        print(df) 
        conn.commit()
        conn.close()

    def update_elder_response_table(self,this_id):
        conn = sqlite3.connect('careall.db')
        c = conn.execute('SELECT COUNT(STATUS) FROM YOUNG_REQUEST_PAGE \
                           WHERE STATUS="accepted" ')
        # Wont allow to accept the request by young whose have got an approval from more than 4 elder
        if c.fetchone()[0] >= 4: 
            print(f'OOPS! Cannot able to response to this {this_id}')
            conn.commit()
            conn.close()
            return False
        else:
            conn.execute(f'UPDATE ELDER_RESPONSE_TABLE \
                            SET STATUS="approved" \
                            WHERE YID={this_id} AND MYEID={self.eid}')
            conn.execute(f'UPDATE YOUNG_RESPONSE_TABLE \
                            SET STATUS="accepted" \
                            WHERE EID={self.eid} AND MYEID={self.eid}')
            conn.commit()
            conn.close()
            return True

    def insert_young_reviews_ratings(self):
        conn = sqlite3.connect('careall.db')
        c = conn.execute(f'SELECT EID FROM YOUNG_REQUEST_PAGE WHERE MYYID = {self.yid} AND STATUS = "accepted"')
        for row in c:
            elder_id = row[0]
            c = conn.execute(f'SELECT ENAME FROM ELDER WHERE EID = {elder_id}')
            ename = c.fetchone()[0]
            print(f'Give a feedback about {ename}, you are taking care of!')
            review = input('Give the reviews: ')
            rating = int(input('Give Rating: '))
            conn.execute(f'INSERT INTO YOUNG_REVIEWS_RATINGS \
                        (YID, EID, REVIEWS, RATINGS) \
                        VALUES (?,?,?,?)',
                        (self.yid, elder_id, review, rating))
                     
        conn.execute('COMMIT')
        conn.close()   
       
    def insert_elder_reviews_ratings(self):
        conn = sqlite3.connect('careall.db')
        c = conn.execute(f'SELECT YID FROM ELDER_REQUEST_PAGE WHERE MYEID = {self.eid} AND STATUS = "approved"')
        for row in c:
            young_id = row[0]
            c = conn.execute(f'SELECT YNAME FROM YOUNG WHERE YID = {young_id}')
            yname = c.fetchone()[0]
            print(f'Give a feedback about {yname}, your caretaker!')
            review = input('Reviews: ')
            rating = int(input('Rating: '))
            conn.execute(f'INSERT INTO ELDER_REVIEWS_RATINGS \
                        (EID, YID, REVIEWS, RATINGS) \
                        VALUES (?,?,?,?)',
                        (self.eid, young_id, review, rating))
                     
        conn.execute('COMMIT')
        conn.close()

    



                     

    


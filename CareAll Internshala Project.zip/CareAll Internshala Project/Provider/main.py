from Common.start import Start_Application

if __name__ == "__main__":

    print('Welcome to the CareAll Program\n\n')
    s = Start_Application()
    s.start()